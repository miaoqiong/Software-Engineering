package Json;

public class sharedSecret {
    private final static String SHARED_SECRET = "qwerty1234567890"; //length 16
    
    public static String get(){
        return SHARED_SECRET;
    }
}

